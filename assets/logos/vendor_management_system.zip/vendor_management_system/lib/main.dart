import 'package:flutter/material.dart';
import 'package:vendor_management_system/utils/theme/theme.dart';

import 'app.dart';

void main() {
  runApp(const App());
}


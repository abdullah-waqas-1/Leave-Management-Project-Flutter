/// LIST OF Enums
/// They cannot be created inside a class.
enum TextSizes { small, medium, large }
enum OrderStatus { processing, shipped, delivered }
enum PaymentMethods { easyPaisa, googlePay, applePay, visa, masterCard, creditCard, razorPay, jazzCash }